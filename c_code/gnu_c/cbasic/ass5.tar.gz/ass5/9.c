//WAP whether a number is power of 2 or not
#include<stdio.h>
int main()
{
int a, count=0;
printf("Enter the number \n");
scanf("%d", &a);

if( (a & (a-1)) ==0)
printf("The number is power of 2 \n");
else
printf("The number is not the power of 2 \n");
return 0;
}
